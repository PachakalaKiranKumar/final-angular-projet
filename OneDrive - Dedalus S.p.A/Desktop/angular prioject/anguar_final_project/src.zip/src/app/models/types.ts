export  type product ={
    id: number,
    name:string,
    type:string,
    price:string, 
    image:string, 
    description:string

}

