import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { MenubarComponent } from './menubar/menubar.component';
import { MaterialModule } from '../material/material.module';
import { DietplanComponent } from './dietplan/dietplan.component';
import { CreateComponent } from './create/create.component';
import { HomeComponent } from './home/home.component';
import { ForumComponent } from './forum/forum.component';


@NgModule({
  declarations: [
    MenubarComponent,
    HomeComponent,
    DietplanComponent,
    CreateComponent,
    ForumComponent
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    MaterialModule
  
  ],
  exports:[
    HomeComponent,
    MenubarComponent,
    
  ]
})
export class UserModule { }
